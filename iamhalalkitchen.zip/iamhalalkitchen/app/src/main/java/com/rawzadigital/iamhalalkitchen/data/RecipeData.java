package com.rawzadigital.iamhalalkitchen.data;

import com.rawzadigital.iamhalalkitchen.R;
import com.rawzadigital.iamhalalkitchen.pojo.RecipeModel;

import java.util.ArrayList;

public class RecipeData {

    public static String[][] titleRecipe = new String[][]{
            {"Chill Coke and Full Burger", "20 min"},
            {"Mixed Fruit, Raspberry and Blueberry", "20 min"},
            {"Soto Bagas", "35 min"},
            {"Soto Bang Jack", "14 min"},
            {"Angkringan Bang Rozaq", "12 min"},
            {"Soto Gobyos", "15 min"},
            {"Susu Segar She Jack", "30 min"},
            {"Spesial Sambal", "20 min"},
            {"Steak Double", "18 min"},
            {"Wes ngantuk sesuk meneh", "23 min"}
    };

    public static int[] imageRecipe = new int[]{
            R.drawable.image_1,
            R.drawable.image_2,
            R.drawable.image_3,
            R.drawable.image_4,
            R.drawable.image_5,
            R.drawable.image_6,
            R.drawable.image_7,
            R.drawable.image_8,
            R.drawable.image_9,
            R.drawable.image_10
    };


    //TODO: ArrayList test cara 1
    /*
    public static ArrayList<RecipeModel> getListData() {
        RecipeModel recipeModel = null;
        ArrayList<RecipeModel> list = new ArrayList<>();
        for (String[] aTitleRecipe : titleRecipe) {
            recipeModel = new RecipeModel();
            recipeModel.setRecipeTitle(aTitleRecipe[0]);
            recipeModel.setRecipeTime(aTitleRecipe[1]);

            //recipeModel.setRecipeImage(imageRecipe[0]);
            recipeModel.setRecipeImage(imageRecipe[0]);
            list.add(recipeModel);

        }

        return list;
    } */


    //TODO: ArrayList test cara 2
    public static ArrayList<RecipeModel> getListData() {
        RecipeModel recipeModel = null;
        ArrayList<RecipeModel> listImage = new ArrayList<>();
        for (int i = 0; i < imageRecipe.length; i++) {
            recipeModel = new RecipeModel();
            recipeModel.setRecipeTitle(titleRecipe[i][0]);
            recipeModel.setRecipeTime(titleRecipe[i][1]);
            recipeModel.setRecipeImage(imageRecipe[i]);

            listImage.add(recipeModel);
        }
        return listImage;
    }

}
