package com.rawzadigital.iamhalalkitchen.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.rawzadigital.iamhalalkitchen.R;
import com.rawzadigital.iamhalalkitchen.adapter.RecipeCardAdapter;
import com.rawzadigital.iamhalalkitchen.data.RecipeData;
import com.rawzadigital.iamhalalkitchen.pojo.RecipeModel;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvMainActivity;
    private ArrayList<RecipeModel> listRecipe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvMainActivity = findViewById(R.id.rv_main_activity);
        rvMainActivity.setHasFixedSize(true);

        listRecipe = new ArrayList<>();
        listRecipe.addAll(RecipeData.getListData());
       // listRecipe.addAll(RecipeData.getListDataImage());

        showCardList();
    }

    private void showCardList(){
        rvMainActivity.setLayoutManager(new LinearLayoutManager(this));
        RecipeCardAdapter recipeCardAdapter = new RecipeCardAdapter(this);
        recipeCardAdapter.setListRecipe(listRecipe);
        rvMainActivity.setAdapter(recipeCardAdapter);
    }
}
