package com.rawzadigital.iamhalalkitchen.pojo;

public class RecipeModel {

    private String recipeTitle, recipeTime, recipeTry;
    private int recipeImage;

    public String getRecipeTitle() {
        return recipeTitle;
    }

    public void setRecipeTitle(String recipeTitle) {
        this.recipeTitle = recipeTitle;
    }

    public String getRecipeTime() {
        return recipeTime;
    }

    public void setRecipeTime(String recipeTime) {
        this.recipeTime = recipeTime;
    }

    public String getRecipeTry() {
        return recipeTry;
    }

    public void setRecipeTry(String recipeTry) {
        this.recipeTry = recipeTry;
    }

    public int getRecipeImage() {
        return recipeImage;
    }

    public void setRecipeImage(int recipeImage) {
        this.recipeImage = recipeImage;
    }
}
